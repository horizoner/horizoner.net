﻿<?php
return array(
	//'配置项'=>'配置值'
	'APP_GROUP_LIST' => 'Index,Admin',
	'DEFAULT_GROUP' => 'Index',

	'APP_GROUP_MODE' => 1,
	'APP_GROUP_PATH' => 'Modules',

	'DB_HOST' => '127.0.0.1',
	'DB_USER' => 'root',
	'DB_PWD' => '',
	'DB_NAME' => 'horizoner',
	'DB_PREFIX' => 'hz_',

	'TMPL_VAR_IDENTIFY' => 'array',
	'TMPL_FILE_DEPR' => '_',


);
?>