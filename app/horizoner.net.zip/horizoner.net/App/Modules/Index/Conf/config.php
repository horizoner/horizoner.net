<?php
	return array(
		'TMPL_EXCEPTION_FILE' => './Public/Tpl/error.html'
	);
?>