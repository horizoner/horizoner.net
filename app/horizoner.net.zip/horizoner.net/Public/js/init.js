define(function(require, exports, module) {
	// var $ = require('jquery');
    exports.conf = {
        sectionContainer: "section",
        animationTime: 600,
        updateURL: true,
        responsiveFallback: 600,
        loop: true,
        //direction: "horizontal"
    };
});